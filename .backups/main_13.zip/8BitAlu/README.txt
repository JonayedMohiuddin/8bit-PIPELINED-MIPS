While loading ALU jar library if logisim asks for a class name enter the class name below it should work,
src.tusharLogisim.MIPSTushar